
  # Página de Missão Emocional

  This is a code bundle for Página de Missão Emocional. The original project is available at https://www.figma.com/design/huaUoh9sUDjYwp83gZcgBv/P%C3%A1gina-de-Miss%C3%A3o-Emocional.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  