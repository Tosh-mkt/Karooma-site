import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ExternalLink, Star, Tag } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const products = [
  {
    id: 1,
    name: "Caixas Organizadoras de Tecido",
    description: "Dobráveis e leves, perfeitas para guardar brinquedos rapidamente.",
    price: "R$ 45,90",
    image: "https://images.unsplash.com/photo-1600096194735-8344418e58b8?w=400",
    tags: ["Cupom ativo", "Recomendado por mães"],
    rating: 4.7,
  },
  {
    id: 2,
    name: "Difusor de Aromas",
    description: "Cria um ambiente calmo e acolhedor enquanto você organiza.",
    price: "R$ 89,90",
    image: "https://images.unsplash.com/photo-1602874801007-dd2d23b94ec0?w=400",
    tags: ["Recomendado por mães"],
    rating: 4.9,
  },
  {
    id: 3,
    name: "Organizador de Mesa Minimalista",
    description: "Mantém a superfície livre e bonita, sem esforço.",
    price: "R$ 34,90",
    image: "https://images.unsplash.com/photo-1580913428706-c311e67898b3?w=400",
    tags: ["Cupom ativo"],
    rating: 4.5,
  },
];

export function ProductRecommendations() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.6 }}
      className="bg-[#FAF7F0]/50 rounded-3xl p-6 md:p-8"
    >
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Tag className="w-5 h-5 text-[#7A9D6F]" />
          <h3>Ferramentas que tornam isso mais fácil</h3>
        </div>
        <p className="text-[#7A9D6F]/70">
          Pequenos objetos que facilitam a leveza no dia a dia
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 mb-6">
        {products.map((product, index) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 + index * 0.1 }}
          >
            <Card className="overflow-hidden border-[#E8DCC4] hover:border-[#9CA986] transition-all hover:shadow-lg">
              <div className="aspect-square overflow-hidden bg-[#E8DCC4]/30">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              
              <div className="p-4">
                <div className="flex flex-wrap gap-2 mb-3">
                  {product.tags.map((tag) => (
                    <Badge
                      key={tag}
                      variant="secondary"
                      className={`text-xs ${
                        tag.includes("Cupom")
                          ? "bg-[#D4A89A]/20 text-[#C4917A]"
                          : "bg-[#9CA986]/20 text-[#7A9D6F]"
                      }`}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>

                <h4 className="mb-2">{product.name}</h4>
                
                <p className="text-sm text-[#7A9D6F]/70 mb-3">
                  {product.description}
                </p>

                <div className="flex items-center gap-2 mb-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(product.rating)
                            ? "fill-[#D4A89A] text-[#D4A89A]"
                            : "text-[#E8DCC4]"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-[#7A9D6F]/70">
                    {product.rating}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-[#7A9D6F]">{product.price}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-[#9CA986] text-[#7A9D6F] hover:bg-[#9CA986] hover:text-white"
                  >
                    Ver na Amazon
                    <ExternalLink className="w-3 h-3 ml-2" />
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="text-center">
        <Button
          variant="ghost"
          className="text-[#7A9D6F] hover:text-[#7A9D6F] hover:bg-[#9CA986]/10"
        >
          Ver mais opções na Amazon
          <ExternalLink className="w-4 h-4 ml-2" />
        </Button>
      </div>
    </motion.div>
  );
}
