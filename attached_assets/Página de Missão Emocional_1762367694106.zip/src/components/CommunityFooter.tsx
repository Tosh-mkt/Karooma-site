import { motion } from "motion/react";
import { Button } from "./ui/button";
import { Users, Send, Leaf } from "lucide-react";

export function CommunityFooter() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.8 }}
      className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#7A9D6F] to-[#9CA986] p-8 md:p-12 text-white text-center"
    >
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-10 left-10">
          <Leaf className="w-24 h-24" />
        </div>
        <div className="absolute bottom-10 right-10">
          <Leaf className="w-32 h-32 rotate-45" />
        </div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <Leaf className="w-40 h-40 rotate-12" />
        </div>
      </div>

      <div className="relative z-10 max-w-2xl mx-auto">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.9, type: "spring", stiffness: 200 }}
          className="w-16 h-16 mx-auto mb-6 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center"
        >
          <Users className="w-8 h-8 text-white" />
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1 }}
          className="mb-4 text-white"
        >
          Você faz parte do Círculo da Leveza
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1 }}
          className="mb-8 text-white/90"
        >
          Um espaço para mães que respiram entre uma missão e outra. 
          Aqui você não está sozinha — está acompanhada por quem entende.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="flex flex-col sm:flex-row gap-4 justify-center"
        >
          <Button
            size="lg"
            variant="secondary"
            className="bg-white text-[#7A9D6F] hover:bg-white/90 shadow-lg"
          >
            <Users className="w-5 h-5 mr-2" />
            Entrar na comunidade
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-2 border-white text-white hover:bg-white/10"
          >
            <Send className="w-5 h-5 mr-2" />
            Receber missões no WhatsApp
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.3 }}
          className="mt-6 text-sm text-white/70"
        >
          Sua jornada de leveza continua aqui 🌿
        </motion.p>
      </div>
    </motion.div>
  );
}
