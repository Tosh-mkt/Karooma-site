import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Card } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Progress } from "./ui/progress";
import { Sparkles, CheckCircle2 } from "lucide-react";
import { toast } from "sonner@2.0.3";

interface ChecklistItem {
  id: string;
  title: string;
  tip: string;
  completed: boolean;
}

interface MissionChecklistProps {
  onComplete: () => void;
}

const initialSteps: ChecklistItem[] = [
  {
    id: "1",
    title: "Escolha 3 itens espalhados pela casa e guarde-os",
    tip: "Não precisa ser perfeito. Só três coisas que te incomodam agora.",
    completed: false,
  },
  {
    id: "2",
    title: "Abra uma janela por 2 minutos",
    tip: "O ar fresco renova o espaço e a sua energia.",
    completed: false,
  },
  {
    id: "3",
    title: "Coloque uma música que te acalme",
    tip: "Deixe tocar enquanto faz as próximas ações.",
    completed: false,
  },
  {
    id: "4",
    title: "Organize a mesa da cozinha ou da sala",
    tip: "Só a superfície visível. O resto pode esperar.",
    completed: false,
  },
  {
    id: "5",
    title: "Respire fundo 3 vezes",
    tip: "Sinta a diferença. Você criou esse espaço.",
    completed: false,
  },
];

const encouragements = [
  "Respira, isso conta.",
  "Você está indo bem. 🌿",
  "Cada passo é uma vitória.",
  "Isso já é muito. ✨",
  "Você está criando leveza.",
];

export function MissionChecklist({ onComplete }: MissionChecklistProps) {
  const [steps, setSteps] = useState<ChecklistItem[]>(initialSteps);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const completed = steps.filter((s) => s.completed).length;
    const newProgress = (completed / steps.length) * 100;
    setProgress(newProgress);

    if (completed === steps.length && completed > 0) {
      setTimeout(() => {
        onComplete();
      }, 800);
    }
  }, [steps, onComplete]);

  const toggleStep = (id: string) => {
    setSteps((prev) =>
      prev.map((step) => {
        if (step.id === id) {
          const newCompleted = !step.completed;
          
          if (newCompleted) {
            const randomEncouragement =
              encouragements[Math.floor(Math.random() * encouragements.length)];
            toast.success(randomEncouragement, {
              duration: 2000,
              className: "bg-[#9CA986] text-white border-none",
            });
          }
          
          return { ...step, completed: newCompleted };
        }
        return step;
      })
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <Card className="p-6 md:p-8 bg-white border-[#E8DCC4]">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-[#7A9D6F]" />
              <span>Seu progresso</span>
            </div>
            <span className="text-sm text-[#7A9D6F]">
              {steps.filter((s) => s.completed).length} de {steps.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <div className="space-y-4">
          {steps.map((step, index) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div
                className={`p-4 rounded-2xl border-2 transition-all cursor-pointer ${
                  step.completed
                    ? "bg-[#9CA986]/10 border-[#9CA986]"
                    : "bg-[#FAF7F0] border-[#E8DCC4] hover:border-[#9CA986]/40"
                }`}
                onClick={() => toggleStep(step.id)}
              >
                <div className="flex gap-4">
                  <div className="pt-1">
                    <Checkbox
                      checked={step.completed}
                      onCheckedChange={() => toggleStep(step.id)}
                      className="w-6 h-6 data-[state=checked]:bg-[#7A9D6F] data-[state=checked]:border-[#7A9D6F]"
                    />
                  </div>
                  
                  <div className="flex-1">
                    <div
                      className={`mb-1 transition-all ${
                        step.completed
                          ? "line-through text-[#7A9D6F]"
                          : ""
                      }`}
                    >
                      {step.title}
                    </div>
                    <p className="text-sm text-[#7A9D6F]/70">{step.tip}</p>
                  </div>

                  <AnimatePresence>
                    {step.completed && (
                      <motion.div
                        initial={{ scale: 0, rotate: -180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        exit={{ scale: 0 }}
                        transition={{ type: "spring", stiffness: 200 }}
                      >
                        <Sparkles className="w-6 h-6 text-[#D4A89A]" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </Card>
    </motion.div>
  );
}
