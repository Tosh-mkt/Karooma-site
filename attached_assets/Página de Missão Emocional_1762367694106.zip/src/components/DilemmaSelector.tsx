import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Coffee, Package, Heart, Baby, Wrench } from "lucide-react";

const dilemmas = [
  {
    id: 1,
    icon: Coffee,
    title: "Minhas manhãs",
    description: "Começar o dia com mais calma",
    color: "#9CA986",
  },
  {
    id: 2,
    icon: Package,
    title: "A bagunça que nunca some",
    description: "Organizar sem exaustão",
    color: "#D4A89A",
  },
  {
    id: 3,
    icon: Heart,
    title: "O tempo pra mim",
    description: "Momentos de autocuidado",
    color: "#C4917A",
  },
  {
    id: 4,
    icon: Baby,
    title: "As crianças cheias de energia",
    description: "Atividades para canalizar a energia",
    color: "#9CA986",
  },
  {
    id: 5,
    icon: Wrench,
    title: "A casa que precisa de um cuidado",
    description: "Pequenos reparos e manutenção",
    color: "#7A9D6F",
  },
];

export function DilemmaSelector() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.7 }}
      className="py-12"
    >
      <div className="text-center mb-8">
        <h2 className="mb-3">O que está te pedindo leveza hoje?</h2>
        <p className="text-[#7A9D6F]/70 max-w-2xl mx-auto">
          Escolha o dilema que mais ressoa com o seu momento atual
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {dilemmas.map((dilemma, index) => {
          const Icon = dilemma.icon;
          return (
            <motion.div
              key={dilemma.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 + index * 0.1 }}
            >
              <Card
                className="p-6 border-2 border-[#E8DCC4] hover:border-[#9CA986] cursor-pointer transition-all hover:shadow-lg hover:-translate-y-1 group"
                style={{
                  background: `linear-gradient(135deg, ${dilemma.color}05 0%, ${dilemma.color}15 100%)`,
                }}
              >
                <div
                  className="w-14 h-14 rounded-2xl mb-4 flex items-center justify-center group-hover:scale-110 transition-transform"
                  style={{ backgroundColor: `${dilemma.color}20` }}
                >
                  <Icon
                    className="w-7 h-7"
                    style={{ color: dilemma.color }}
                  />
                </div>
                
                <h4 className="mb-2">{dilemma.title}</h4>
                
                <p className="text-sm text-[#7A9D6F]/70">
                  {dilemma.description}
                </p>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </motion.div>
  );
}
