import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Clock, Zap, Home } from "lucide-react";

export function MissionSummary() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="p-6 bg-[#FAF7F0] border-[#E8DCC4]">
        <div className="flex flex-wrap gap-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#9CA986]/20 flex items-center justify-center">
              <Clock className="w-6 h-6 text-[#7A9D6F]" />
            </div>
            <div>
              <div className="text-sm text-[#7A9D6F]">Tempo estimado</div>
              <div>5 minutos</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#D4A89A]/20 flex items-center justify-center">
              <Zap className="w-6 h-6 text-[#C4917A]" />
            </div>
            <div>
              <div className="text-sm text-[#7A9D6F]">Energia</div>
              <div>Baixa</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#E8DCC4]/60 flex items-center justify-center">
              <Home className="w-6 h-6 text-[#7A9D6F]" />
            </div>
            <div>
              <div className="text-sm text-[#7A9D6F]">Categoria</div>
              <div>Casa em Ordem</div>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-[#E8DCC4]">
          <p className="text-[#7A9D6F]/80">
            Essa missão é pra quando o dia parece grande demais.
          </p>
        </div>
      </Card>
    </motion.div>
  );
}
