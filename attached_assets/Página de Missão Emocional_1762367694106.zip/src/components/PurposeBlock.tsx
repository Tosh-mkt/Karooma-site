import { motion } from "motion/react";
import { Heart } from "lucide-react";

export function PurposeBlock() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
      className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#D4A89A]/20 to-[#E8DCC4]/40 p-8 md:p-10"
    >
      <div className="absolute top-6 right-6 opacity-10">
        <Heart className="w-32 h-32 text-[#D4A89A]" />
      </div>
      
      <div className="relative z-10">
        <div className="inline-flex items-center gap-2 mb-4 text-[#C4917A]">
          <Heart className="w-5 h-5" />
          <span>Por que isso importa?</span>
        </div>
        
        <p className="text-[#5A5A5A] max-w-2xl leading-relaxed">
          Não é sobre arrumar a casa, é sobre sentir que o dia voltou a caber em você. 
          Pequenos gestos criam espaço — não só físico, mas emocional. Você merece esse 
          respiro, essa leveza que vem de saber que fez algo por você.
        </p>
      </div>
    </motion.div>
  );
}
