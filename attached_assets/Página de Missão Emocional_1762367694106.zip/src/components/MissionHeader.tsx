import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Button } from "./ui/button";
import { Leaf } from "lucide-react";

interface MissionHeaderProps {
  onStart: () => void;
}

export function MissionHeader({ onStart }: MissionHeaderProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#9CA986] to-[#7A9D6F] p-8 md:p-12 text-white"
    >
      <div className="absolute inset-0 opacity-20">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1650472363263-b5a6bd792d18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3RoZXIlMjBtb3JuaW5nJTIwY2hhb3MlMjB0b3lzfGVufDF8fHx8MTc2MjM2Njg4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Rotina matinal"
          className="h-full w-full object-cover"
        />
      </div>
      
      <div className="relative z-10 max-w-2xl">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="inline-flex items-center gap-2 mb-4 px-4 py-2 bg-white/20 backdrop-blur-sm rounded-full"
        >
          <Leaf className="w-4 h-4" />
          <span className="text-sm">Missão do Dia</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mb-4"
        >
          Entre o caos e o carinho — essa missão é pra você.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mb-6 text-white/90"
        >
          5 minutos para aliviar a rotina matinal.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Button
            onClick={onStart}
            size="lg"
            className="bg-white text-[#7A9D6F] hover:bg-white/90 shadow-lg"
          >
            <Leaf className="w-5 h-5 mr-2" />
            Começar leve
          </Button>
        </motion.div>
      </div>
    </motion.div>
  );
}
