import { motion } from "motion/react";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback } from "./ui/avatar";
import { MessageCircle, Plus } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const testimonials = [
  {
    id: 1,
    name: "Mariana",
    initial: "M",
    text: "Fiz hoje e me senti leve! Não sabia que 5 minutos podiam fazer tanta diferença.",
    timeAgo: "há 2 horas",
  },
  {
    id: 2,
    name: "Camila",
    initial: "C",
    text: "Organizei com meu filho, foi divertido. Ele escolheu a música! 🎵",
    timeAgo: "há 5 horas",
  },
  {
    id: 3,
    name: "Juliana",
    initial: "J",
    text: "Respirei fundo e senti que estava cuidando de mim também, não só da casa.",
    timeAgo: "ontem",
  },
];

export function CommunityTestimonials() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
    >
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <MessageCircle className="w-6 h-6 text-[#7A9D6F]" />
          <h3>Outras mães disseram</h3>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-6">
        {testimonials.map((testimonial, index) => (
          <motion.div
            key={testimonial.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 + index * 0.1 }}
          >
            <Card className="p-5 bg-white border-[#E8DCC4] hover:border-[#9CA986] transition-colors">
              <div className="flex items-start gap-3 mb-3">
                <Avatar className="w-10 h-10">
                  <AvatarFallback className="bg-[#9CA986] text-white">
                    {testimonial.initial}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div>{testimonial.name}</div>
                  <div className="text-sm text-[#7A9D6F]/60">
                    {testimonial.timeAgo}
                  </div>
                </div>
              </div>
              <p className="text-[#5A5A5A]">{testimonial.text}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="relative h-48 rounded-2xl overflow-hidden mb-4">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1761933803826-7782e8bfe7fd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXJtJTIwbW90aGVycyUyMHRvZ2V0aGVyJTIwY29tbXVuaXR5fGVufDF8fHx8MTc2MjM2Njg4OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Comunidade de mães"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#7A9D6F]/80 to-transparent flex items-end p-6">
          <div className="text-white">
            <p className="mb-2">Você também faz parte disso.</p>
            <Button
              variant="secondary"
              className="bg-white text-[#7A9D6F] hover:bg-white/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Compartilhe sua leveza (+3 pontos)
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
