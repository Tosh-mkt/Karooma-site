import { motion, AnimatePresence } from "motion/react";
import { Button } from "./ui/button";
import { Sparkles, Share2, ArrowRight } from "lucide-react";

interface CompletionRewardProps {
  isVisible: boolean;
  onClose: () => void;
}

export function CompletionReward({ isVisible, onClose }: CompletionRewardProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.8, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            className="bg-white rounded-3xl p-8 md:p-12 max-w-md w-full text-center relative overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-[#9CA986]/10 to-[#D4A89A]/10 pointer-events-none" />
            
            <motion.div
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
              className="relative z-10 mb-6"
            >
              <div className="w-24 h-24 mx-auto bg-gradient-to-br from-[#9CA986] to-[#7A9D6F] rounded-full flex items-center justify-center">
                <Sparkles className="w-12 h-12 text-white" />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="relative z-10"
            >
              <h2 className="mb-4">Você completou sua missão 🌼</h2>
              
              <p className="text-[#7A9D6F] mb-6">
                Respira, a leveza chegou. Você criou espaço — não só na casa, mas em você.
              </p>

              <div className="inline-flex items-center gap-3 px-6 py-3 bg-[#FAF7F0] rounded-full mb-8">
                <Sparkles className="w-5 h-5 text-[#D4A89A]" />
                <span>+10 Pontos de Leveza</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  variant="outline"
                  className="flex-1 border-[#9CA986] text-[#7A9D6F] hover:bg-[#9CA986]/10"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Compartilhar
                </Button>
                <Button
                  className="flex-1 bg-[#7A9D6F] hover:bg-[#6A8D5F] text-white"
                  onClick={onClose}
                >
                  Explorar novas missões
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </div>
            </motion.div>

            <motion.div
              animate={{
                y: [0, -10, 0],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="absolute top-10 right-10 text-[#D4A89A]/30"
            >
              <Sparkles className="w-8 h-8" />
            </motion.div>

            <motion.div
              animate={{
                y: [0, 10, 0],
                opacity: [0.3, 0.6, 0.3],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 1,
              }}
              className="absolute bottom-10 left-10 text-[#9CA986]/30"
            >
              <Sparkles className="w-6 h-6" />
            </motion.div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
