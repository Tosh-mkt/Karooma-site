import { useState } from "react";
import { MissionHeader } from "./components/MissionHeader";
import { MissionSummary } from "./components/MissionSummary";
import { MissionChecklist } from "./components/MissionChecklist";
import { PurposeBlock } from "./components/PurposeBlock";
import { CommunityTestimonials } from "./components/CommunityTestimonials";
import { ProductRecommendations } from "./components/ProductRecommendations";
import { CompletionReward } from "./components/CompletionReward";
import { DilemmaSelector } from "./components/DilemmaSelector";
import { CommunityFooter } from "./components/CommunityFooter";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  const [started, setStarted] = useState(false);
  const [showReward, setShowReward] = useState(false);

  const handleStart = () => {
    setStarted(true);
    setTimeout(() => {
      document.getElementById("mission-summary")?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 100);
  };

  const handleComplete = () => {
    setShowReward(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FAF7F0] to-white">
      <Toaster />
      <CompletionReward isVisible={showReward} onClose={() => setShowReward(false)} />
      
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <MissionHeader onStart={handleStart} />

        {started && (
          <>
            <div id="mission-summary" className="mt-8">
              <MissionSummary />
            </div>

            <div className="mt-8">
              <MissionChecklist onComplete={handleComplete} />
            </div>

            <div className="mt-12">
              <PurposeBlock />
            </div>

            <div className="mt-12">
              <CommunityTestimonials />
            </div>

            <div className="mt-12">
              <ProductRecommendations />
            </div>

            <div className="mt-12">
              <DilemmaSelector />
            </div>

            <div className="mt-12">
              <CommunityFooter />
            </div>
          </>
        )}
      </div>
    </div>
  );
}
